# KELVIN • AURA / ATELIER 2.0

A personal Android launcher for Kelvin Mwendwa Mutuku. A new wallpaper-backed desktop, Windows-inspired tile layouts, a Start-style command center and original artwork. No publishing, account, advertising, analytics or Internet permission.

## Upgrade from the first AURA project

1. Extract this ZIP into a NEW folder so you have a clean project. Keep your previous project until the update works.
2. In Android Studio, File → Open → select the inner **KelvinAura** folder containing `settings.gradle`, `build.gradle` and `app`.
3. Select **Gradle JDK 17** in Settings → Build, Execution, Deployment → Build Tools → Gradle. Keep Distribution set to Wrapper. This project uses Gradle 8.9 / Android Gradle Plugin 8.7.3 / SDK 35.
4. Allow Gradle sync to complete. If requested, install Android SDK Platform 35.
5. Connect your Android 11+ phone by USB, accept USB debugging, select **app** and your phone, then click Run ▶.
6. The package remains `com.kelvin.aura`, with versionCode 2 / versionName 2.0. Using the same computer/debug signing key normally installs this over the first version and retains its data. **Do not uninstall or clear app data to upgrade:** that deletes encrypted notes and preferences. A signing-key mismatch requires a separate migration decision; stop and keep the old install/data.
7. In AURA, tap Set AURA as default home if necessary. To revert, open Privacy → Switch to your original launcher, or use Android Settings → Default apps → Home.

This is a multi-file update: MainActivity now uses BaseActivity and Art. Copying only MainActivity into the original project will not work. Open the complete new folder.

## What changed

- **Three desktops:** Atelier shows personal dashboard tiles and pinned apps; Metro adds a larger shortcut tile area; Quiet strips back the dashboard for a calmer screen.
- **Wallpaper-backed home screen:** the selected gallery artwork becomes AURA's backdrop, with a dark translucent layer so the text remains readable.
- **48 original wallpaper variants:** eight compositions × six colorways, rendered locally. This is 48 designed combinations, not 48 unrelated photographs.
- **Eight families:** Silk Bloom, Glass Portal, Dune Atelier, Aurora Veil, Contour Earth, Orbital Noir, Metro Mosaic and Celestial.
- **Six colorways:** Sapphire, Champagne, Amethyst, Jade, Rose and Ice.
- **Gallery controls:** category filtering, saved artwork, previews, desktop application and optional home/lock/both system-wallpaper application. Static system wallpapers render at 1440 × 2560; the phone may crop/scale them.
- **Import your own photo:** uses Android's file picker and applies the image as system wallpaper. AURA's own desktop keeps its gallery artwork; the import does not become a gallery entry.
- **Live canvas:** slow motion, optional touch ripples and optional 15-minute artwork rotation. Animation stops when the wallpaper is not visible. It is an Android live wallpaper, selected through the system preview.
- **Start / command center:** search installed apps; type focus, studio, notes, calculator or settings for matching command shortcuts.
- **Pinned app grid:** long press an app, or tap its ⋮ menu, to pin/unpin it.
- **Named app collections:** assign apps through the app menu; filter them with collection tabs in Start. Choose Remove from collection to remove an assignment. Hidden apps remain excluded.
- **Accent controls:** Gold, Blue, Amethyst or Mint; optional day/night accent chosen when the screen redraws.
- **Focus room:** 25/50-minute timer, current intention and Do Not Disturb shortcut. Countdown survives process restart on the same boot; reboot resets it. No background alarm or notification.
- **Checklist:** add tasks, mark completion and remove completed entries.
- **Quick calculator:** addition, subtraction, multiplication, division and percentage-of.
- **Unit converter:** kilometres/miles, Celsius/Fahrenheit and kilograms/pounds.
- **Scratchpad:** local plain-text notes. This tool is NOT encrypted; use Privacy → Encrypted private notes for private content.
- **Month view:** a local calendar viewer; it does not read/write calendar events.
- **Presentation mode:** hides the daily intention on the desktop. It does not lock or hide anything in the system.
- **Desktop export/import:** copy/paste validated JSON containing name, palette, wallpaper selection and layout. This excludes encrypted notes, scratchpad, checklist, app groups, pinned apps and hidden-app data.
- **Privacy center retained:** authenticated encrypted notes, authenticated hidden-app management, screenshot protection, device details and system settings shortcuts.

## First five things to try

1. Studio → Desktop layout → Metro.
2. In the gallery, open **Silk Bloom / Sapphire** or **Glass Portal / Champagne** → Use artwork → choose desktop-only or a system destination.
3. Open Start and pin four apps. Add work/social apps to named collections.
4. Studio → Animated gallery / live wallpaper → confirm the system preview. Open Live wallpaper options to enable rotation or reduce motion.
5. Tools → Focus room / checklist / calculator. Change your intention and name to personalize the desktop.

Selecting a wallpaper updates the AURA desktop immediately; applying it to Android home/lock is a separate optional step. Touch ripple support depends on the launcher forwarding touches to the live wallpaper. Rotation is calculated from the clock in 15-minute slots while the wallpaper is visible; it is not a background wallpaper-changing alarm. When motion is disabled, the live canvas checks for rotation every 30 seconds. Live wallpaper may consume more battery than static wallpaper.

## Privacy and Android boundaries

Private notes use AES-256-GCM with an Android Keystore key requiring recent strong biometric/device-credential authentication. Notes relock when AURA leaves the foreground and block screenshots while open. Save before leaving. Authentication is requested again when saving. Removing screen lock, key invalidation, clearing data or uninstalling can permanently lose notes. There is no cloud backup or recovery. Scratchpad/checklist/preferences use app-private storage but are not separately encrypted.

Hidden apps are hidden only in AURA, not locked system-wide. They may still open from notifications, Android settings or other launchers. Screenshot blocking applies only to AURA windows. It does not prevent every form of recording or guarantee device security.

This is a launcher, not a replacement operating system. It does not change the notification shade, Settings design, system fonts, lock-screen controls or every other app's appearance. It has no antivirus, device tracking, accessibility service, root requirement or device-admin access. Windows inspires the tile organization and Start concept; no Microsoft wallpaper files, logos or commercial theme packs are included. Similar features exist in other products; this is a personalized combination, not a claim of worldwide feature exclusivity.

Some Xiaomi/HyperOS devices restrict gesture navigation with third-party launchers. If navigation is unreliable, use the phone's three-button navigation setting. Keep the factory launcher installed for an easy return.

## Verification

- All Java source compiled successfully with Java 17 against Google's official Android API 35 public SDK classes. An independent Eclipse Java compiler check also passed before final formatting/validation.
- XML resources parsed successfully and required manifest components/resources were checked.
- All 48 original artwork variants were rendered through a Java2D graphics adapter for visual review. `WALLPAPER_COLLECTION_PREVIEW.png` is an approximate artwork contact sheet, not an Android screenshot; Android rendering can differ.
- The complete Gradle/APK build and physical-device UI/security tests have NOT been run here. Gradle could not download its distribution from this runtime's Java networking environment. Your previously working Android Studio/JDK17 setup is the intended build environment.

### Phone acceptance checklist

Build/install without uninstalling the first version; confirm previous notes still decrypt. Test each layout, Home button, Back navigation, keyboard, larger font size and return to original launcher. Search/launch/pin/group/hide/unhide apps. Preview all eight artwork families; test saved filters and wallpaper destinations. Import a large photo. Test live wallpaper visible/hidden behavior, motion toggle and rotation. Verify focus countdown after switching apps and process restart, calculator divide-by-zero, converter, checklist persistence and JSON import rejection. Cancel private-note authentication and confirm no plaintext is shown; save a test note and verify it after leaving/returning; test screenshot protection.

## Project source

- MainActivity.java — Atelier interface, gallery, desktop, collections and tools.
- BaseActivity.java — shared launcher helpers and retained authenticated privacy center.
- Art.java — all eight original wallpaper drawing algorithms and six palettes.
- AuraWallpaper.java — cached live-canvas drawing and lifecycle/rotation/touch behavior.
- Vault.java — Keystore encryption/decryption.

## Official research references

https://developer.android.com/reference/android/app/role/RoleManager
https://developer.android.com/reference/android/app/WallpaperManager
https://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine
https://developer.android.com/training/data-storage/shared/documents-files
https://developer.android.com/privacy-and-security/keystore
https://developer.android.com/reference/android/hardware/biometrics/BiometricPrompt

Artwork and interface were created for this project. Gradle wrapper files are from the official Gradle v8.9.0 repository and retain their upstream license notices. No paid theme assets were copied. No third-party runtime library was added to the Android application.
