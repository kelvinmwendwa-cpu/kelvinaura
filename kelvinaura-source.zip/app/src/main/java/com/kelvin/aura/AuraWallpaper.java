package com.kelvin.aura;

import android.content.SharedPreferences;
import android.graphics.*;
import android.os.*;
import android.service.wallpaper.WallpaperService;
import android.view.*;

/** Battery-aware animated canvas with optional visible-time gallery rotation. */
public class AuraWallpaper extends WallpaperService {
  public Engine onCreateEngine() {
    return new AtelierEngine();
  }

  class AtelierEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
    Handler h = new Handler(Looper.getMainLooper());
    boolean visible;
    Bitmap artwork;
    int lastArt = -1, lastWidth, lastHeight;
    float touchX = -1, touchY = -1;
    long touchTime;
    SharedPreferences p;
    Paint paint = new Paint(3);
    Runnable frame = () -> draw();

    public void onCreate(SurfaceHolder holder) {
      super.onCreate(holder);
      p = getSharedPreferences("aura", 0);
      p.registerOnSharedPreferenceChangeListener(this);
      setTouchEventsEnabled(true);
    }

    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
      lastArt = -1;
      if (visible) draw();
    }

    public void onVisibilityChanged(boolean v) {
      visible = v;
      h.removeCallbacks(frame);
      if (v) draw();
    }

    public void onSurfaceChanged(SurfaceHolder sh, int format, int w, int height) {
      super.onSurfaceChanged(sh, format, w, height);
      lastArt = -1;
      if (visible) draw();
    }

    public void onSurfaceDestroyed(SurfaceHolder sh) {
      visible = false;
      h.removeCallbacks(frame);
      release();
      super.onSurfaceDestroyed(sh);
    }

    public void onDestroy() {
      visible = false;
      h.removeCallbacks(frame);
      if (p != null) p.unregisterOnSharedPreferenceChangeListener(this);
      release();
      super.onDestroy();
    }

    void release() {
      if (artwork != null) {
        artwork.recycle();
        artwork = null;
      }
    }

    public void onTouchEvent(android.view.MotionEvent e) {
      if (e.getAction() == MotionEvent.ACTION_DOWN && p.getBoolean("ripple", true)) {
        touchX = e.getX();
        touchY = e.getY();
        touchTime = SystemClock.elapsedRealtime();
        if (visible) draw();
      }
      super.onTouchEvent(e);
    }

    void draw() {
      h.removeCallbacks(frame);
      if (!visible || p == null) return;
      Canvas c = null;
      boolean animate = p.getBoolean("motion", true);
      long now = SystemClock.elapsedRealtime();
      try {
        c = getSurfaceHolder().lockCanvas();
        if (c != null) {
          int w = c.getWidth(), height = c.getHeight();
          int id = Art.clamp(p.getInt("art", 0));
          if (p.getBoolean("rotation", false))
            id = (id + (int) (System.currentTimeMillis() / 900000L % 48)) % 48;
          if (artwork == null || id != lastArt || w != lastWidth || height != lastHeight) {
            release();
            int bw = Math.min(w, 720),
                bh = Math.max(1, Math.round(bw * (height / (float) Math.max(1, w))));
            artwork = Art.bitmap(Math.max(1, bw), bh, id);
            lastArt = id;
            lastWidth = w;
            lastHeight = height;
          }
          c.drawColor(0xff08101c);
          float shift = animate ? (float) Math.sin(now / 16000d) * w * .015f : 0;
          paint.setAlpha(255);
          paint.setStyle(Paint.Style.FILL);
          c.drawBitmap(
              artwork,
              null,
              new RectF(-w * .04f + shift, -height * .04f, w * 1.04f + shift, height * 1.04f),
              paint);
          if (animate) {
            paint.setShader(
                new RadialGradient(
                    w * .65f + (float) Math.sin(now / 9000d) * w * .2f,
                    height * .4f,
                    w * .7f,
                    new int[] {0x1878bfff, 0},
                    null,
                    Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, height, paint);
            paint.setShader(null);
          }
          if (touchX >= 0 && now - touchTime < 1100 && p.getBoolean("ripple", true)) {
            float progress = (now - touchTime) / 1100f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2);
            paint.setColor(0xffd5e7ff);
            paint.setAlpha((int) (160 * (1 - progress)));
            c.drawCircle(touchX, touchY, progress * w * .65f, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setAlpha(255);
          }
        }
      } catch (Exception ignored) {
      } finally {
        if (c != null) getSurfaceHolder().unlockCanvasAndPost(c);
      }
      if (visible) h.postDelayed(frame, animate || now - touchTime < 1100 ? 50 : 30000);
    }
  }
}
