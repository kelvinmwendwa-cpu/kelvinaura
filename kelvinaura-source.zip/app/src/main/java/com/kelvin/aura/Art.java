package com.kelvin.aura;

import android.graphics.*;
import java.util.Random;

/** Original procedural collection: eight compositions in six colorways. */
final class Art {
  static final String[] FAMILIES = {
    "Silk Bloom",
    "Glass Portal",
    "Dune Atelier",
    "Aurora Veil",
    "Contour Earth",
    "Orbital Noir",
    "Metro Mosaic",
    "Celestial"
  };
  static final String[] TONES = {"Sapphire", "Champagne", "Amethyst", "Jade", "Rose", "Ice"};
  static final int[][] PALETTES = {
    {0xff09152c, 0xff214f9b, 0xff72b4ff},
    {0xff16120e, 0xff83613c, 0xffefcf92},
    {0xff150d28, 0xff6442a3, 0xffc6a0ff},
    {0xff071e20, 0xff187c72, 0xff8be1bd},
    {0xff241320, 0xffa74669, 0xffffb7be},
    {0xff0b1922, 0xff406a80, 0xffb7e5ed}
  };

  static int clamp(int n) {
    return Math.max(0, Math.min(47, n));
  }

  static String name(int id) {
    id = clamp(id);
    return FAMILIES[id / 6] + " / " + TONES[id % 6];
  }

  static Bitmap bitmap(int w, int h, int id) {
    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    draw(new Canvas(b), w, h, id, 0);
    return b;
  }

  static void draw(Canvas c, float w, float h, int id, float phase) {
    id = clamp(id);
    int[] col = PALETTES[id % 6];
    Paint p = new Paint(3);
    c.save();
    c.scale(w / 1000f, h / 1800f);
    float W = 1000, H = 1800;
    p.setShader(
        new LinearGradient(
            0, 0, W, H, new int[] {col[0], col[1], col[0]}, null, Shader.TileMode.CLAMP));
    c.drawRect(0, 0, W, H, p);
    p.setShader(null);
    Random r = new Random(91 + id);
    float drift = (float) Math.sin(phase) * 35;
    switch (id / 6) {
      case 0: // Folded luminous silk; no copied Windows artwork.
        c.rotate(-22, 500, 900);
        for (int i = 0; i < 34; i++) {
          float x = 60 + i * 26;
          Path path = new Path();
          path.moveTo(x, -180);
          path.cubicTo(x - 500, 350, x + 720, 690, x + 180, 1100);
          path.cubicTo(x - 130, 1420, x + 100, 1640, x + 400, 2040);
          p.setStyle(Paint.Style.STROKE);
          p.setStrokeWidth(23);
          p.setShader(
              new LinearGradient(
                  x,
                  0,
                  x + 400,
                  H,
                  new int[] {col[0], col[2], col[1], col[0]},
                  null,
                  Shader.TileMode.CLAMP));
          p.setAlpha(100 + i * 4);
          c.drawPath(path, p);
        }
        break;
      case 1:
        c.rotate(-17, 500, 900);
        for (int i = 9; i >= 0; i--) {
          p.setStyle(Paint.Style.FILL);
          p.setColor(col[2]);
          p.setAlpha(10 + i * 3);
          float pad = i * 25;
          c.drawRoundRect(180 - pad, 450 - pad, 820 + pad, 1300 + pad, 140, 140, p);
        }
        for (int i = 0; i < 9; i++) {
          p.setStyle(Paint.Style.STROKE);
          p.setStrokeWidth(5 + i * 2);
          p.setShader(
              new LinearGradient(
                  100,
                  300,
                  900,
                  1500,
                  new int[] {col[2], col[1], col[0], col[2]},
                  null,
                  Shader.TileMode.CLAMP));
          p.setAlpha(220 - i * 14);
          float d = i * 28;
          c.drawRoundRect(150 + d, 380 + d, 850 - d, 1420 - d, 120, 120, p);
        }
        break;
      case 2:
        for (int i = 0; i < 8; i++) {
          Path path = new Path();
          path.moveTo(-50, 760 + i * 138);
          path.cubicTo(240, 420 + i * 148, 540 + drift, 1250 + i * 50, 1050, 600 + i * 148);
          path.lineTo(1050, 1900);
          path.lineTo(-50, 1900);
          path.close();
          p.setShader(
              new LinearGradient(
                  0,
                  650 + i * 130,
                  600,
                  1800,
                  new int[] {i % 2 == 0 ? col[2] : col[1], col[0]},
                  null,
                  Shader.TileMode.CLAMP));
          c.drawPath(path, p);
        }
        break;
      case 3:
        for (int i = 0; i < 55; i++) {
          Path path = new Path();
          float x = i * 26 - 250;
          path.moveTo(x, -80);
          path.cubicTo(x + 650, 500 + drift, x - 400, 990, x + 800, 1900);
          p.setStyle(Paint.Style.STROKE);
          p.setStrokeWidth(18);
          p.setShader(
              new LinearGradient(
                  0,
                  0,
                  800,
                  H,
                  new int[] {col[0], col[2], col[1], col[0]},
                  null,
                  Shader.TileMode.CLAMP));
          p.setAlpha(25 + (int) (80 * Math.sin(i * .04)));
          c.drawPath(path, p);
        }
        break;
      case 4:
        for (int i = 0; i < 65; i++) {
          Path path = new Path();
          for (int y = -30; y <= 1850; y += 20) {
            float x =
                500
                    + (float) Math.sin(y * .004 + i * .055) * 210
                    + (float) Math.cos(y * .007 + i * .1) * 90
                    + i * 15
                    - 480;
            if (y == -30) path.moveTo(x, y);
            else path.lineTo(x, y);
          }
          p.setStyle(Paint.Style.STROKE);
          p.setStrokeWidth(i % 5 == 0 ? 3 : 1.2f);
          p.setColor(col[2]);
          p.setAlpha(i % 5 == 0 ? 150 : 65);
          c.drawPath(path, p);
        }
        break;
      case 5:
        for (int i = 0; i < 25; i++) {
          p.setStyle(Paint.Style.STROKE);
          p.setColor(col[2]);
          p.setAlpha(25 + i * 4);
          p.setStrokeWidth(1.5f);
          c.drawCircle(790 + drift, 1120, 140 + i * 24, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setShader(
            new RadialGradient(
                360, 670, 260, new int[] {col[2], col[1], col[0]}, null, Shader.TileMode.CLAMP));
        c.drawCircle(360, 670, 255, p);
        break;
      case 6:
        c.rotate(-12, 500, 900);
        for (int y = -1; y < 7; y++)
          for (int x = -1; x < 5; x++) {
            p.setColor((x + y) % 3 == 0 ? col[2] : col[1]);
            p.setAlpha(30 + r.nextInt(150));
            float X = x * 270, Y = y * 300;
            c.drawRoundRect(X + 14, Y + 14, X + 254, Y + 284, 22, 22, p);
          }
        break;
      case 7:
        for (int i = 0; i < 170; i++) {
          p.setColor(col[2]);
          p.setAlpha(60 + r.nextInt(160));
          c.drawCircle(r.nextFloat() * W, r.nextFloat() * H, 1 + r.nextFloat() * 2.5f, p);
        }
        p.setShader(
            new RadialGradient(
                690, 610, 210, new int[] {col[2], col[1], col[0]}, null, Shader.TileMode.CLAMP));
        c.drawCircle(690, 610, 205, p);
        p.setShader(null);
        p.setColor(col[0]);
        c.drawCircle(765, 540, 192, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(col[2]);
        p.setAlpha(70);
        c.drawOval(-220, 1100, 1250, 1570, p);
        break;
    }
    c.restore();
  }
}
