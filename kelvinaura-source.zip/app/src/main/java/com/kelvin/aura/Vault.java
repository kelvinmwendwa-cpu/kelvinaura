package com.kelvin.aura;

import android.content.Context;
import android.security.keystore.*;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

final class Vault {
  static javax.crypto.SecretKey key() throws Exception {
    KeyStore k = KeyStore.getInstance("AndroidKeyStore");
    k.load(null);
    if (!k.containsAlias("aura_notes")) {
      KeyGenerator g = KeyGenerator.getInstance("AES", "AndroidKeyStore");
      g.init(
          new KeyGenParameterSpec.Builder(
                  "aura_notes", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
              .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
              .setKeySize(256)
              .setUserAuthenticationRequired(true)
              .setUserAuthenticationParameters(
                  60, KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL)
              .build());
      g.generateKey();
    }
    return (javax.crypto.SecretKey) k.getKey("aura_notes", null);
  }

  static void save(Context c, String s) throws Exception {
    Cipher x = Cipher.getInstance("AES/GCM/NoPadding");
    x.init(Cipher.ENCRYPT_MODE, key());
    String data =
        Base64.encodeToString(x.getIV(), Base64.NO_WRAP)
            + ":"
            + Base64.encodeToString(
                x.doFinal(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)), Base64.NO_WRAP);
    if (!c.getSharedPreferences("vault", 0).edit().putString("note", data).commit())
      throw new java.io.IOException("Save failed");
  }

  static String read(Context c) throws Exception {
    String data = c.getSharedPreferences("vault", 0).getString("note", "");
    if (data.isEmpty()) return "";
    String[] a = data.split(":");
    Cipher x = Cipher.getInstance("AES/GCM/NoPadding");
    x.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(a[0], 0)));
    return new String(x.doFinal(Base64.decode(a[1], 0)), java.nio.charset.StandardCharsets.UTF_8);
  }
}
