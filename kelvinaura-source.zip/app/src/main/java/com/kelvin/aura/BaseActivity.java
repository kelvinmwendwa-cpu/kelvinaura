package com.kelvin.aura;

import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.hardware.biometrics.*;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class BaseActivity extends Activity {
  android.content.SharedPreferences prefs;
  LinearLayout root, body;
  TextView clock;
  String page = "Home";
  int accent, bg;
  Handler handler = new Handler();
  long focusEnd = 0;
  boolean vaultOpen = false;
  EditText note;
  int[] colors = {0xffe8c785, 0xff94bfff, 0xffb3a1ff, 0xff72dcc4};
  String[] themes = {"Obsidian Gold", "Arctic Blue", "Royal Amethyst", "Emerald Night"};
  Runnable tick =
      new Runnable() {
        public void run() {
          if (clock != null)
            clock.setText(
                new java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
          if (page.equals("Focus") && focusEnd > 0) updateFocus();
          handler.postDelayed(this, 1000);
        }
      };

  public void onCreate(Bundle b) {
    super.onCreate(b);
    prefs = getSharedPreferences("aura", 0);
    render();
    handler.post(tick);
  }

  protected void onDestroy() {
    handler.removeCallbacks(tick);
    super.onDestroy();
  }

  protected void onPause() {
    super.onPause();
    if (vaultOpen) {
      vaultOpen = false;
      note = null;
      page = "Home";
      render();
    }
  }

  protected void onResume() {
    super.onResume();
    if (root != null && !vaultOpen) render();
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density);
  }

  GradientDrawable panel() {
    GradientDrawable g = new GradientDrawable();
    g.setColor(0xdd192334);
    g.setCornerRadius(dp(22));
    g.setStroke(dp(1), 0xff344254);
    return g;
  }

  TextView label(String s, int size) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(size);
    t.setTextColor(0xfff1f3f8);
    t.setPadding(dp(8), dp(9), dp(8), dp(9));
    return t;
  }

  void button(LinearLayout box, String s, Runnable action) {
    TextView t = label(s, 16);
    t.setTextColor(accent);
    t.setBackground(panel());
    LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
    l.setMargins(0, dp(5), 0, dp(5));
    box.addView(t, l);
    t.setOnClickListener(v -> action.run());
  }

  void info(String s) {
    body.addView(label(s, 14));
  }

  void toast(String s) {
    Toast.makeText(this, s, Toast.LENGTH_LONG).show();
  }

  void go(Intent i) {
    try {
      startActivity(i);
    } catch (Exception e) {
      toast("This feature is not available on this phone.");
    }
  }

  void render() {
    if (vaultOpen || prefs.getBoolean("secure", false))
      getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    accent = colors[prefs.getInt("theme", 0)];
    bg = 0xff0a101c;
    getWindow().setStatusBarColor(bg);
    getWindow().setNavigationBarColor(bg);
    root = new LinearLayout(this);
    root.setOrientation(1);
    root.setPadding(dp(18), 0, dp(18), 0);
    root.setBackground(
        new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {bg, 0xff172238, bg}));
    setContentView(root);
    root.setOnApplyWindowInsetsListener(
        (v, in) -> {
          android.graphics.Insets ins = in.getInsets(WindowInsets.Type.systemBars());
          v.setPadding(dp(18), ins.top, dp(18), ins.bottom);
          return in;
        });
    root.requestApplyInsets();
    TextView brand = label(prefs.getString("owner", "KELVIN") + "  /  A U R A", 15);
    brand.setTextColor(accent);
    root.addView(brand);
    ScrollView scroll = new ScrollView(this);
    body = new LinearLayout(this);
    body.setOrientation(1);
    scroll.addView(body);
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    clock = null;
    switch (page) {
      case "Home":
        home();
        break;
      case "Apps":
        apps();
        break;
      case "Studio":
        studio();
        break;
      case "Focus":
        focus();
        break;
      case "Privacy":
        privacy();
        break;
    }
    LinearLayout nav = new LinearLayout(this);
    for (String s : new String[] {"Home", "Apps", "Studio", "Focus", "Privacy"}) {
      TextView t = label(s, 12);
      t.setGravity(Gravity.CENTER);
      t.setTextColor(page.equals(s) ? accent : 0xff9caabc);
      nav.addView(t, new LinearLayout.LayoutParams(0, dp(56), 1));
      t.setOnClickListener(
          v -> {
            vaultOpen = false;
            note = null;
            page = s;
            render();
          });
    }
    root.addView(nav);
  }

  void home() {
    clock = label("", 64);
    body.addView(clock);
    info(new java.text.SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()));
    info("Your space. Your pace.");
    Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    int level = b == null ? 0 : b.getIntExtra("level", 0),
        scale = b == null ? 100 : b.getIntExtra("scale", 100);
    info(
        "BATTERY  "
            + (scale > 0 ? level * 100 / scale : 0)
            + "%   •   "
            + themes[prefs.getInt("theme", 0)]);
    button(
        body,
        "Search your apps  ↗",
        () -> {
          page = "Apps";
          render();
        });
    info("FAVORITES · long press an app to customize");
    for (ResolveInfo a : list()) {
      String id = id(a);
      if (prefs.getStringSet("favorites", new HashSet<>()).contains(id)
          && !prefs.getStringSet("hidden", new HashSet<>()).contains(id)) appRow(body, a);
    }
    button(
        body,
        "Make AURA your home screen",
        () -> {
          RoleManager r = getSystemService(RoleManager.class);
          if (r.isRoleAvailable(RoleManager.ROLE_HOME))
            go(r.createRequestRoleIntent(RoleManager.ROLE_HOME));
          else go(new Intent(Settings.ACTION_HOME_SETTINGS));
        });
    button(
        body,
        "Camera",
        () -> go(new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)));
    button(body, "Phone", () -> go(new Intent(Intent.ACTION_DIAL)));
    button(
        body,
        "Internet controls",
        () -> go(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)));
    button(
        body, "Alarm clock", () -> go(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)));
    button(
        body,
        "Today's intention",
        () -> {
          EditText e = new EditText(this);
          e.setText(prefs.getString("intention", "Build something worthwhile."));
          new AlertDialog.Builder(this)
              .setTitle("One thing that matters today")
              .setView(e)
              .setPositiveButton(
                  "Save",
                  (d, n) -> {
                    prefs.edit().putString("intention", e.getText().toString()).apply();
                    render();
                  })
              .setNegativeButton("Cancel", null)
              .show();
        });
    info(prefs.getString("intention", "Build something worthwhile."));
    button(body, "System settings", () -> go(new Intent(Settings.ACTION_SETTINGS)));
  }

  String id(ResolveInfo a) {
    return new ComponentName(a.activityInfo.packageName, a.activityInfo.name).flattenToString();
  }

  java.util.List<ResolveInfo> list() {
    Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
    java.util.List<ResolveInfo> all = getPackageManager().queryIntentActivities(i, 0);
    all.sort(
        (a, b) ->
            a.loadLabel(getPackageManager())
                .toString()
                .compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
    return all;
  }

  void toggle(String k, String s) {
    Set<String> set = new HashSet<>(prefs.getStringSet(k, new HashSet<>()));
    if (!set.add(s)) set.remove(s);
    prefs.edit().putStringSet(k, set).apply();
    render();
  }

  void appRow(LinearLayout box, ResolveInfo a) {
    LinearLayout row = new LinearLayout(this);
    row.setGravity(Gravity.CENTER_VERTICAL);
    row.setPadding(dp(12), dp(8), dp(12), dp(8));
    ImageView icon = new ImageView(this);
    icon.setImageDrawable(a.loadIcon(getPackageManager()));
    row.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
    TextView text = label(a.loadLabel(getPackageManager()).toString(), 16);
    row.addView(text);
    box.addView(row);
    row.setOnClickListener(
        v ->
            go(
                new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(
                        new ComponentName(a.activityInfo.packageName, a.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
    row.setOnLongClickListener(
        v -> {
          new AlertDialog.Builder(this)
              .setTitle(a.loadLabel(getPackageManager()))
              .setItems(
                  new String[] {"Toggle favorite", "Toggle hide in AURA", "App information"},
                  (d, n) -> {
                    if (n == 0) toggle("favorites", id(a));
                    if (n == 1) toggle("hidden", id(a));
                    if (n == 2)
                      go(
                          new Intent(
                              Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                              android.net.Uri.parse("package:" + a.activityInfo.packageName)));
                  })
              .show();
          return true;
        });
  }

  void apps() {
    body.addView(label("Your apps", 30));
    EditText search = new EditText(this);
    search.setSingleLine();
    search.setTextColor(Color.WHITE);
    search.setHintTextColor(0xffaaaaaa);
    search.setHint("Search by name");
    body.addView(search);
    LinearLayout items = new LinearLayout(this);
    items.setOrientation(1);
    body.addView(items);
    java.util.List<ResolveInfo> all = list();
    Runnable fill =
        () -> {
          items.removeAllViews();
          String q = search.getText().toString().toLowerCase(Locale.ROOT);
          for (ResolveInfo a : all)
            if (!prefs.getStringSet("hidden", new HashSet<>()).contains(id(a))
                && a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT).contains(q))
              appRow(items, a);
        };
    search.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

          public void onTextChanged(CharSequence s, int st, int b, int c) {
            fill.run();
          }

          public void afterTextChanged(Editable e) {}
        });
    fill.run();
  }

  void studio() {
    body.addView(label("Theme studio", 30));
    info("Choose your signature palette");
    for (int i = 0; i < themes.length; i++) {
      final int n = i;
      button(
          body,
          themes[i],
          () -> {
            prefs.edit().putInt("theme", n).apply();
            render();
          });
    }
    button(
        body,
        "Personalize your name",
        () -> {
          EditText e = new EditText(this);
          e.setText(prefs.getString("owner", "KELVIN"));
          new AlertDialog.Builder(this)
              .setTitle("Your signature")
              .setView(e)
              .setPositiveButton(
                  "Save",
                  (d, n) -> {
                    String s = e.getText().toString().trim();
                    prefs
                        .edit()
                        .putString(
                            "owner",
                            s.isEmpty() ? "KELVIN" : s.substring(0, Math.min(24, s.length())))
                        .apply();
                    render();
                  })
              .setNegativeButton("Cancel", null)
              .show();
        });
    button(
        body,
        "Animated orbit wallpaper",
        () ->
            go(
                new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, AuraWallpaper.class))));
    info("ORIGINAL WALLPAPERS · generated on your phone");
    ImageView preview = new ImageView(this);
    preview.setImageBitmap(wallpaper(360, 640));
    preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
    body.addView(preview, new LinearLayout.LayoutParams(-1, dp(240)));
    button(
        body,
        "Apply wallpaper",
        () ->
            new AlertDialog.Builder(this)
                .setTitle("Wallpaper destination")
                .setItems(
                    new String[] {"Home screen", "Lock screen", "Both"},
                    (d, n) -> {
                      new Thread(
                              () -> {
                                try {
                                  WallpaperManager.getInstance(this)
                                      .setBitmap(
                                          wallpaper(1080, 1920),
                                          null,
                                          false,
                                          n == 0
                                              ? WallpaperManager.FLAG_SYSTEM
                                              : n == 1
                                                  ? WallpaperManager.FLAG_LOCK
                                                  : WallpaperManager.FLAG_SYSTEM
                                                      | WallpaperManager.FLAG_LOCK);
                                  runOnUiThread(() -> toast("Wallpaper applied"));
                                } catch (Exception e) {
                                  runOnUiThread(
                                      () ->
                                          toast("Wallpaper could not be applied on this device."));
                                }
                              })
                          .start();
                    })
                .show());
  }

  Bitmap wallpaper(int w, int h) {
    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(b);
    Paint p = new Paint(3);
    p.setShader(
        new LinearGradient(
            0,
            0,
            w,
            h,
            new int[] {0xff080d18, 0xff21314a, 0xff080d18},
            null,
            Shader.TileMode.CLAMP));
    c.drawRect(0, 0, w, h, p);
    p.setShader(null);
    p.setStyle(Paint.Style.STROKE);
    p.setStrokeWidth(w / 400f);
    for (int i = 0; i < 24; i++) {
      p.setColor(accent);
      p.setAlpha(20 + i * 3);
      c.drawCircle(w * .84f, h * .64f, w * .16f + i * w * .035f, p);
    }
    p.setStyle(Paint.Style.FILL);
    p.setAlpha(255);
    p.setTextSize(w * .036f);
    p.setTypeface(Typeface.create("sans-serif-light", 0));
    c.drawText("A U R A", w * .09f, h * .85f, p);
    p.setTextSize(w * .02f);
    c.drawText(
        prefs.getString("owner", "KELVIN").toUpperCase(Locale.ROOT) + "  •  PERSONAL EDITION",
        w * .09f,
        h * .88f,
        p);
    return b;
  }

  void updateFocus() {
    render();
  }

  void focus() {
    body.addView(label("Focus space", 30));
    if (focusEnd > 0) {
      long seconds = Math.max(0, (focusEnd - SystemClock.elapsedRealtime()) / 1000);
      body.addView(label(String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60), 56));
      if (seconds == 0) {
        focusEnd = 0;
        toast("Focus session complete");
      }
    } else info("Give one task your full attention.");
    button(
        body,
        "Start 25 minutes",
        () -> {
          focusEnd = SystemClock.elapsedRealtime() + 25 * 60 * 1000;
          render();
        });
    button(
        body,
        "Start 50 minutes",
        () -> {
          focusEnd = SystemClock.elapsedRealtime() + 50 * 60 * 1000;
          render();
        });
    button(
        body,
        "End session",
        () -> {
          focusEnd = 0;
          render();
        });
    info(
        "Timer runs while the app process lives. It does not block apps or send background"
            + " alarms.");
    button(
        body,
        "Open Do Not Disturb settings",
        () -> go(new Intent("android.settings.ZEN_MODE_SETTINGS")));
  }

  void auth(Runnable done) {
    KeyguardManager km = getSystemService(KeyguardManager.class);
    if (!km.isDeviceSecure()) {
      toast("First set a screen lock in Android settings.");
      return;
    }
    new BiometricPrompt.Builder(this)
        .setTitle("AURA private space")
        .setSubtitle("Confirm your identity")
        .setAllowedAuthenticators(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        .build()
        .authenticate(
            new CancellationSignal(),
            getMainExecutor(),
            new BiometricPrompt.AuthenticationCallback() {
              public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                done.run();
              }

              public void onAuthenticationError(int c, CharSequence s) {
                toast(s.toString());
              }
            });
  }

  void privacy() {
    body.addView(label("Privacy center", 30));
    info("Offline by design • No ads • No account • No Internet permission");
    button(
        body,
        "Encrypted private notes",
        () ->
            auth(
                () -> {
                  try {
                    String text = Vault.read(this);
                    vaultOpen = true;
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                    body.removeAllViews();
                    body.addView(label("Private notes", 28));
                    note = new EditText(this);
                    note.setTextColor(Color.WHITE);
                    note.setMinLines(8);
                    note.setGravity(Gravity.TOP);
                    note.setText(text);
                    body.addView(note);
                    button(
                        body,
                        "Authenticate & save",
                        () -> {
                          String content = note.getText().toString();
                          auth(
                              () -> {
                                try {
                                  Vault.save(this, content);
                                  toast("Encrypted note saved");
                                } catch (Exception e) {
                                  toast(
                                      "Could not save. Authenticate again; keep your text until"
                                          + " saved.");
                                }
                              });
                        });
                    button(
                        body,
                        "Close private space",
                        () -> {
                          vaultOpen = false;
                          note = null;
                          getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
                          render();
                        });
                    info(
                        "Save before leaving. Notes relock when AURA leaves the foreground."
                            + " Uninstalling loses notes permanently.");
                  } catch (Exception e) {
                    toast(
                        "Cannot decrypt notes. Device security may have changed. No data was"
                            + " overwritten.");
                  }
                }));
    button(
        body,
        "Manage hidden apps",
        () ->
            auth(
                () -> {
                  java.util.List<ResolveInfo> hidden = new ArrayList<>();
                  for (ResolveInfo a : list())
                    if (prefs.getStringSet("hidden", new HashSet<>()).contains(id(a)))
                      hidden.add(a);
                  String[] names = new String[hidden.size()];
                  for (int x = 0; x < names.length; x++)
                    names[x] = hidden.get(x).loadLabel(getPackageManager()).toString();
                  new AlertDialog.Builder(this)
                      .setTitle("Tap an app to unhide")
                      .setItems(names, (d, n) -> toggle("hidden", id(hidden.get(n))))
                      .setPositiveButton("Close", null)
                      .show();
                }));
    button(
        body,
        "Protect AURA from screenshots: " + (prefs.getBoolean("secure", false) ? "ON" : "OFF"),
        () -> {
          prefs.edit().putBoolean("secure", !prefs.getBoolean("secure", false)).apply();
          render();
        });
    button(
        body, "Android security settings", () -> go(new Intent(Settings.ACTION_SECURITY_SETTINGS)));
    button(
        body,
        "Device information",
        () ->
            new AlertDialog.Builder(this)
                .setTitle("Your device")
                .setMessage(
                    Build.MANUFACTURER
                        + " "
                        + Build.MODEL
                        + "\nAndroid "
                        + Build.VERSION.RELEASE
                        + "\nSecurity patch: "
                        + Build.VERSION.SECURITY_PATCH
                        + "\nAURA 2.0 • Atelier edition")
                .setPositiveButton("Close", null)
                .show());
    button(
        body,
        "Application permissions",
        () -> go(new Intent(Settings.ACTION_APPLICATION_SETTINGS)));
    button(
        body,
        "Switch to your original launcher",
        () -> go(new Intent(Settings.ACTION_HOME_SETTINGS)));
    info(
        "Hidden apps remain accessible from settings and other entry points. AURA cannot lock other"
            + " apps, replace system security, theme every application, or prevent device theft.");
  }

  public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (prefs != null) {
      if (vaultOpen || prefs.getBoolean("secure", false))
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
      else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }
  }
}
