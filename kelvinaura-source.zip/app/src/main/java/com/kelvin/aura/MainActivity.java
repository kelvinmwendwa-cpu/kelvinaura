package com.kelvin.aura;

import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** AURA Atelier: tile desktop, original wallpaper studio and offline personal tools. */
public class MainActivity extends BaseActivity {
  TextView countdown;
  Bitmap deskArt;
  int artKey = -1;
  String collection = "All";
  int artFamily = -1;
  boolean onlySaved = false;
  volatile int pageToken = 0;
  final Handler ui = new Handler(Looper.getMainLooper());
  java.util.concurrent.ExecutorService worker =
      java.util.concurrent.Executors.newSingleThreadExecutor();
  android.util.LruCache<Integer, Bitmap> thumbs = new android.util.LruCache<Integer, Bitmap>(18);
  final String[] modes = {"Atelier", "Metro", "Quiet"};

  @Override
  public void onCreate(Bundle b) {
    super.onCreate(b);
    int boot = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT, -1);
    if (prefs.getInt("timer_boot", -2) == boot) focusEnd = prefs.getLong("timer_end", 0);
    render();
  }

  @Override
  protected void onDestroy() {
    ui.removeCallbacksAndMessages(null);
    worker.shutdownNow();
    super.onDestroy();
  }

  int selectedArt() {
    return Art.clamp(prefs.getInt("art", 0));
  }

  @Override
  GradientDrawable panel() {
    GradientDrawable g = new GradientDrawable();
    g.setColor(0xdf122033);
    g.setCornerRadius(dp(23));
    g.setStroke(dp(1), 0x557ca1bf);
    return g;
  }

  @Override
  TextView label(String s, int size) {
    TextView t = super.label(s, size);
    t.setFontFeatureSettings("kern");
    return t;
  }

  @Override
  void button(LinearLayout box, String title, Runnable action) {
    TextView t = label(title + "   ›", 15);
    t.setPadding(dp(17), dp(16), dp(17), dp(16));
    t.setTextColor(0xffe9f1ff);
    t.setBackground(panel());
    t.setFocusable(true);
    t.setClickable(true);
    LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
    l.setMargins(0, dp(5), 0, dp(5));
    box.addView(t, l);
    t.setOnClickListener(v -> action.run());
  }

  void heading(String eyebrow, String title, String subtitle) {
    TextView e = label(eyebrow, 11);
    e.setTextColor(accent);
    e.setLetterSpacing(.18f);
    body.addView(e);
    TextView t = label(title, 32);
    t.setTypeface(Typeface.create("sans-serif-medium", 0));
    body.addView(t);
    if (!subtitle.isEmpty()) info(subtitle);
  }

  void navigate(String p) {
    vaultOpen = false;
    note = null;
    page = p;
    render();
  }

  @Override
  void render() {
    if (prefs == null) return;
    pageToken++;
    countdown = null;
    clock = null;
    int palette = prefs.getInt("theme", 0);
    accent = colors[Math.max(0, Math.min(colors.length - 1, palette))];
    if (prefs.getBoolean("auto_accent", false)) {
      int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
      accent = hour >= 18 || hour < 6 ? 0xffd7b4ff : 0xffa2d5ff;
    }
    if (vaultOpen || prefs.getBoolean("secure", false))
      getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    getWindow().setStatusBarColor(0xff08101c);
    getWindow().setNavigationBarColor(0xff08101c);
    FrameLayout frame = new FrameLayout(this);
    int key = selectedArt();
    if (deskArt == null || artKey != key) {
      deskArt = Art.bitmap(540, 960, key);
      artKey = key;
    }
    ImageView backdrop = new ImageView(this);
    backdrop.setImageBitmap(deskArt);
    backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
    frame.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));
    View shade = new View(this);
    shade.setBackgroundColor(page.equals("Home") ? 0x82050c18 : 0xea080f1c);
    frame.addView(shade, new FrameLayout.LayoutParams(-1, -1));
    root = new LinearLayout(this);
    root.setOrientation(1);
    root.setPadding(dp(18), dp(18), dp(18), dp(8));
    frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
    setContentView(frame);
    frame.setOnApplyWindowInsetsListener(
        (v, in) -> {
          Insets ins = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
          root.setPadding(dp(18), ins.top + dp(8), dp(18), ins.bottom + dp(4));
          return in;
        });
    frame.requestApplyInsets();
    LinearLayout bar = new LinearLayout(this);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    TextView name = label("A / AURA", 15);
    name.setTypeface(Typeface.DEFAULT_BOLD);
    name.setTextColor(accent);
    bar.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
    TextView edition = label("ATELIER 02", 10);
    edition.setLetterSpacing(.12f);
    bar.addView(edition);
    edition.setOnClickListener(v -> navigate("Studio"));
    root.addView(bar);
    ScrollView scroll = new ScrollView(this);
    scroll.setFillViewport(true);
    body = new LinearLayout(this);
    body.setOrientation(1);
    body.setPadding(0, dp(8), 0, dp(18));
    scroll.addView(body);
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    switch (page) {
      case "Home":
        home();
        break;
      case "Apps":
        apps();
        break;
      case "Studio":
        studio();
        break;
      case "Focus":
        focus();
        break;
      case "Privacy":
        privacy();
        break;
      case "Tools":
        tools();
        break;
    }
    LinearLayout nav = new LinearLayout(this);
    nav.setBackground(panel());
    String[] labels = {"Desktop", "Start", "Studio", "Tools", "Privacy"},
        pages = {"Home", "Apps", "Studio", "Tools", "Privacy"};
    for (int i = 0; i < labels.length; i++) {
      final String dest = pages[i];
      TextView t = label(labels[i], 11);
      t.setGravity(Gravity.CENTER);
      t.setTextColor(page.equals(dest) ? accent : 0xffa6b8cb);
      nav.addView(t, new LinearLayout.LayoutParams(0, dp(54), 1));
      t.setOnClickListener(v -> navigate(dest));
    }
    root.addView(nav);
  }

  LinearLayout card(String title, String text) {
    LinearLayout c = new LinearLayout(this);
    c.setOrientation(1);
    c.setPadding(dp(12), dp(10), dp(12), dp(10));
    c.setBackground(panel());
    TextView t = label(title, 12);
    t.setTextColor(accent);
    c.addView(t);
    c.addView(label(text, 17));
    LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
    l.setMargins(0, dp(6), 0, dp(6));
    body.addView(c, l);
    return c;
  }

  void tiles(LinearLayout box, String[] titles, Runnable[] actions) {
    for (int i = 0; i < titles.length; i += 2) {
      LinearLayout row = new LinearLayout(this);
      for (int j = i; j < Math.min(i + 2, titles.length); j++) {
        final int n = j;
        TextView t = label(titles[j], 17);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(16), dp(20), dp(12), dp(20));
        t.setBackground(panel());
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(112), 1);
        l.setMargins(dp(3), dp(4), dp(3), dp(4));
        row.addView(t, l);
        t.setOnClickListener(v -> actions[n].run());
      }
      if (i + 1 == titles.length)
        row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
      box.addView(row);
    }
  }

  @Override
  void home() {
    String owner = prefs.getString("owner", "KELVIN");
    clock =
        label(new java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 68);
    clock.setTypeface(Typeface.create("sans-serif-thin", 0));
    body.addView(clock);
    info(new java.text.SimpleDateFormat("EEEE • dd MMMM", Locale.getDefault()).format(new Date()));
    TextView greeting =
        label(
            "Good "
                + (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 12
                    ? "morning"
                    : Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 18
                        ? "afternoon"
                        : "evening")
                + ", "
                + owner
                + ".",
            22);
    body.addView(greeting);
    button(body, "⌕   Start / search / commands", () -> navigate("Apps"));
    String mode = prefs.getString("layout", "Atelier");
    if (!mode.equals("Quiet")) {
      Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
      int lvl = battery == null ? 0 : battery.getIntExtra("level", 0),
          scale = battery == null ? 100 : battery.getIntExtra("scale", 100);
      tiles(
          body,
          new String[] {
            "◉  Battery\n" + (scale > 0 ? lvl * 100 / scale : 0) + "%",
            "◷  Focus\n25 minutes",
            "▧  Collection\n48 wallpapers",
            "✦  Shuffle\nA new atmosphere"
          },
          new Runnable[] {
            () -> go(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)),
            () -> navigate("Focus"),
            () -> navigate("Studio"),
            () -> {
              prefs.edit().putInt("art", new Random().nextInt(48)).apply();
              render();
            }
          });
    }
    if (mode.equals("Metro"))
      tiles(
          body,
          new String[] {"▣  Camera", "☎  Phone", "≋  Internet", "⚙  Settings"},
          new Runnable[] {
            () -> go(new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
            () -> go(new Intent(Intent.ACTION_DIAL)),
            () -> go(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)),
            () -> go(new Intent(Settings.ACTION_SETTINGS))
          });
    if (!prefs.getBoolean("presentation", false))
      card("TODAY'S INTENTION", prefs.getString("intention", "Make room for exceptional things."));
    info("PINNED APPS   /   HOLD TO ORGANIZE");
    int count = 0;
    LinearLayout row = null;
    for (ResolveInfo a : list()) {
      if (prefs.getStringSet("favorites", new HashSet<>()).contains(id(a)) && !isHidden(a)) {
        if (count % 4 == 0) {
          row = new LinearLayout(this);
          body.addView(row);
        }
        appTile(row, a);
        count++;
      }
    }
    if (count == 0) info("Open Start, hold an app, and pin it here.");
    if (row != null)
      for (int i = count % 4; i > 0 && i < 4; i++)
        row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(90), 1));
    button(body, "Personalize this desktop", () -> navigate("Studio"));
    if (!getSystemService(RoleManager.class).isRoleHeld(RoleManager.ROLE_HOME))
      button(
          body,
          "Set AURA as default home",
          () ->
              go(
                  getSystemService(RoleManager.class)
                      .createRequestRoleIntent(RoleManager.ROLE_HOME)));
  }

  boolean isHidden(ResolveInfo a) {
    return prefs.getStringSet("hidden", new HashSet<>()).contains(id(a));
  }

  void launch(ResolveInfo a) {
    go(
        new Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(new ComponentName(a.activityInfo.packageName, a.activityInfo.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
  }

  void appMenu(ResolveInfo a) {
    new AlertDialog.Builder(this)
        .setTitle(a.loadLabel(getPackageManager()))
        .setItems(
            new String[] {
              "Pin / unpin desktop", "Add to collection", "Hide in AURA", "Android app information"
            },
            (d, n) -> {
              if (n == 0) toggle("favorites", id(a));
              if (n == 1) chooseCollection(a);
              if (n == 2) toggle("hidden", id(a));
              if (n == 3)
                go(
                    new Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + a.activityInfo.packageName)));
            })
        .show();
  }

  void appTile(LinearLayout row, ResolveInfo a) {
    LinearLayout tile = new LinearLayout(this);
    tile.setOrientation(1);
    tile.setGravity(Gravity.CENTER);
    tile.setPadding(dp(2), dp(8), dp(2), dp(8));
    ImageView icon = new ImageView(this);
    icon.setImageDrawable(a.loadIcon(getPackageManager()));
    tile.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
    TextView t = label(a.loadLabel(getPackageManager()).toString(), 11);
    t.setGravity(Gravity.CENTER);
    t.setMaxLines(2);
    t.setEllipsize(TextUtils.TruncateAt.END);
    tile.addView(t);
    row.addView(tile, new LinearLayout.LayoutParams(0, dp(102), 1));
    tile.setOnClickListener(v -> launch(a));
    tile.setOnLongClickListener(
        v -> {
          appMenu(a);
          return true;
        });
  }

  @Override
  void appRow(LinearLayout box, ResolveInfo a) {
    LinearLayout row = new LinearLayout(this);
    row.setGravity(Gravity.CENTER_VERTICAL);
    row.setPadding(dp(9), dp(10), dp(9), dp(10));
    ImageView icon = new ImageView(this);
    icon.setImageDrawable(a.loadIcon(getPackageManager()));
    row.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(38)));
    TextView t = label(a.loadLabel(getPackageManager()).toString(), 16);
    row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
    TextView menu = label("⋮", 22);
    row.addView(menu);
    menu.setOnClickListener(v -> appMenu(a));
    box.addView(row);
    row.setOnClickListener(v -> launch(a));
    row.setOnLongClickListener(
        v -> {
          appMenu(a);
          return true;
        });
  }

  Set<String> collections() {
    return new TreeSet<>(prefs.getStringSet("collections", new HashSet<>()));
  }

  void chooseCollection(ResolveInfo a) {
    Set<String> names = collections();
    names.add("+ New collection");
    String[] items = names.toArray(new String[0]);
    new AlertDialog.Builder(this)
        .setTitle("Organize app")
        .setItems(
            items,
            (d, n) -> {
              if (items[n].equals("+ New collection"))
                input(
                    "Collection name",
                    "",
                    name -> {
                      if (name.isEmpty()
                          || name.length() > 32
                          || name.equals("All")
                          || name.equals("Pinned")
                          || name.equals("+ New collection")) {
                        toast(
                            "Use a collection name of 1–32 characters, other than All or Pinned.");
                        return;
                      }
                      Set<String> all = collections();
                      all.add(name);
                      prefs
                          .edit()
                          .putStringSet("collections", all)
                          .putString("group_" + id(a), name)
                          .apply();
                      render();
                    });
              else {
                prefs.edit().putString("group_" + id(a), items[n]).apply();
                render();
              }
            })
        .setNeutralButton(
            "Remove from collection",
            (d, n) -> {
              prefs.edit().remove("group_" + id(a)).apply();
              render();
            })
        .show();
  }

  interface TextAction {
    void run(String value);
  }

  void input(String title, String value, TextAction action) {
    EditText e = new EditText(this);
    e.setText(value);
    e.setTextColor(Color.WHITE);
    new AlertDialog.Builder(this)
        .setTitle(title)
        .setView(e)
        .setPositiveButton("Save", (d, n) -> action.run(e.getText().toString().trim()))
        .setNegativeButton("Cancel", null)
        .show();
  }

  @Override
  void apps() {
    heading(
        "COMMAND CENTER",
        "Start",
        "Search apps or type: focus, studio, notes, calculator, settings.");
    EditText q = new EditText(this);
    q.setSingleLine();
    q.setTextColor(Color.WHITE);
    q.setHintTextColor(0xff94a8c2);
    q.setHint("Search your space…");
    body.addView(q);
    HorizontalScrollView hs = new HorizontalScrollView(this);
    LinearLayout chips = new LinearLayout(this);
    hs.addView(chips);
    body.addView(hs);
    Set<String> cs = new LinkedHashSet<>();
    cs.add("All");
    cs.add("Pinned");
    cs.addAll(collections());
    for (String name : cs) {
      TextView t = label(name, 13);
      t.setTextColor(collection.equals(name) ? accent : 0xffa9bad0);
      chips.addView(t);
      t.setOnClickListener(
          v -> {
            collection = name;
            render();
          });
    }
    LinearLayout result = new LinearLayout(this);
    result.setOrientation(1);
    body.addView(result);
    java.util.List<ResolveInfo> all = list();
    Runnable fill =
        () -> {
          result.removeAllViews();
          String term = q.getText().toString().trim().toLowerCase(Locale.ROOT);
          String[] cmd = {"focus", "studio", "notes", "calculator", "settings"};
          for (String c : cmd)
            if (!term.isEmpty() && c.startsWith(term))
              button(
                  result,
                  "Command / " + c,
                  () -> {
                    if (c.equals("settings")) go(new Intent(Settings.ACTION_SETTINGS));
                    else if (c.equals("calculator")) calculator();
                    else
                      navigate(
                          c.equals("notes") ? "Privacy" : c.equals("studio") ? "Studio" : "Focus");
                  });
          int count = 0;
          for (ResolveInfo a : all)
            if (!isHidden(a)
                && a.loadLabel(getPackageManager())
                    .toString()
                    .toLowerCase(Locale.ROOT)
                    .contains(term)
                && (collection.equals("All")
                    || collection.equals("Pinned")
                        && prefs.getStringSet("favorites", new HashSet<>()).contains(id(a))
                    || collection.equals(prefs.getString("group_" + id(a), "")))) {
              appRow(result, a);
              count++;
            }
          if (count == 0) result.addView(label("No matching apps in this collection.", 14));
        };
    q.addTextChangedListener(
        new TextWatcher() {
          public void beforeTextChanged(CharSequence s, int start, int c, int a) {}

          public void onTextChanged(CharSequence s, int start, int before, int count) {
            fill.run();
          }

          public void afterTextChanged(Editable e) {}
        });
    fill.run();
  }

  @Override
  void studio() {
    heading(
        "PERSONALIZATION",
        "The atelier",
        "48 original wallpapers. Eight visual families. Your signature.");
    button(
        body,
        "Desktop layout / " + prefs.getString("layout", "Atelier"),
        () ->
            new AlertDialog.Builder(this)
                .setTitle("Choose your desktop")
                .setItems(
                    modes,
                    (d, n) -> {
                      prefs.edit().putString("layout", modes[n]).apply();
                      render();
                    })
                .show());
    button(
        body,
        "Accent / day–night: " + (prefs.getBoolean("auto_accent", false) ? "Auto" : "Manual"),
        () ->
            new AlertDialog.Builder(this)
                .setTitle("Accent palette")
                .setItems(
                    new String[] {"Gold", "Blue", "Amethyst", "Mint", "Automatic day / night"},
                    (d, n) -> {
                      prefs
                          .edit()
                          .putBoolean("auto_accent", n == 4)
                          .putInt("theme", n == 4 ? 0 : n)
                          .apply();
                      render();
                    })
                .show());
    button(
        body,
        "Your signature",
        () ->
            input(
                "Your name",
                prefs.getString("owner", "KELVIN"),
                s -> {
                  prefs
                      .edit()
                      .putString(
                          "owner",
                          s.isEmpty() ? "KELVIN" : s.substring(0, Math.min(24, s.length())))
                      .apply();
                  render();
                }));
    button(
        body,
        "Import a photo wallpaper",
        () -> {
          Intent i =
              new Intent(Intent.ACTION_OPEN_DOCUMENT)
                  .setType("image/*")
                  .addCategory(Intent.CATEGORY_OPENABLE);
          startActivityForResult(i, 71);
        });
    button(
        body,
        "Animated gallery / live wallpaper",
        () ->
            go(
                new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, AuraWallpaper.class))));
    button(
        body,
        "Live wallpaper options",
        () ->
            new AlertDialog.Builder(this)
                .setTitle("Live canvas")
                .setMultiChoiceItems(
                    new String[] {
                      "Rotate artwork every 15 minutes while visible",
                      "Motion (turn off for battery saving)",
                      "Touch ripple"
                    },
                    new boolean[] {
                      prefs.getBoolean("rotation", false),
                      prefs.getBoolean("motion", true),
                      prefs.getBoolean("ripple", true)
                    },
                    (d, n, on) ->
                        prefs
                            .edit()
                            .putBoolean(n == 0 ? "rotation" : n == 1 ? "motion" : "ripple", on)
                            .apply())
                .setPositiveButton("Done", null)
                .show());
    button(
        body,
        onlySaved ? "Showing saved wallpapers / show all" : "Show only saved wallpapers",
        () -> {
          onlySaved = !onlySaved;
          render();
        });
    HorizontalScrollView hs = new HorizontalScrollView(this);
    LinearLayout filters = new LinearLayout(this);
    hs.addView(filters);
    body.addView(hs);
    for (int i = -1; i < 8; i++) {
      final int n = i;
      TextView t = label(i < 0 ? "All" : Art.FAMILIES[i], 12);
      t.setTextColor(artFamily == i ? accent : 0xffa6b6ca);
      filters.addView(t);
      t.setOnClickListener(
          v -> {
            artFamily = n;
            render();
          });
    }
    int count = 0;
    LinearLayout row = null;
    final int token = pageToken;
    for (int i = 0; i < 48; i++) {
      if (artFamily >= 0 && i / 6 != artFamily) continue;
      if (onlySaved && !prefs.getStringSet("saved_art", new HashSet<>()).contains("" + i)) continue;
      final int id = i;
      if (count % 2 == 0) {
        row = new LinearLayout(this);
        body.addView(row);
      }
      LinearLayout item = new LinearLayout(this);
      item.setOrientation(1);
      item.setBackground(panel());
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
      lp.setMargins(dp(3), dp(5), dp(3), dp(5));
      row.addView(item, lp);
      ImageView img = new ImageView(this);
      img.setScaleType(ImageView.ScaleType.CENTER_CROP);
      item.addView(img, new LinearLayout.LayoutParams(-1, dp(185)));
      TextView title = label(Art.name(i) + (i == selectedArt() ? " ✓" : ""), 11);
      title.setMaxLines(2);
      item.addView(title);
      Bitmap cached = thumbs.get(i);
      if (cached != null) img.setImageBitmap(cached);
      else
        worker.submit(
            () -> {
              if (pageToken != token) return;
              Bitmap b = Art.bitmap(180, 300, id);
              thumbs.put(id, b);
              ui.post(
                  () -> {
                    if (pageToken == token) img.setImageBitmap(b);
                  });
            });
      item.setOnClickListener(v -> previewArt(id));
      count++;
    }
    if (count == 0) info("No saved wallpapers here yet. Open any artwork and tap Save / unsave.");
    if (row != null && count % 2 == 1)
      row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
  }

  void previewArt(int id) {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(1);
    ImageView img = new ImageView(this);
    img.setImageBitmap(Art.bitmap(540, 960, id));
    img.setScaleType(ImageView.ScaleType.CENTER_CROP);
    box.addView(img, new LinearLayout.LayoutParams(-1, dp(330)));
    TextView detail = label("Original artwork • " + Art.TONES[id % 6], 13);
    box.addView(detail);
    new AlertDialog.Builder(this)
        .setTitle(Art.FAMILIES[id / 6])
        .setView(box)
        .setPositiveButton(
            "Use artwork",
            (d, n) -> {
              prefs.edit().putInt("art", id).apply();
              render();
              new AlertDialog.Builder(this)
                  .setTitle("Desktop updated. Also set system wallpaper?")
                  .setItems(
                      new String[] {"Home screen", "Lock screen", "Both"},
                      (dialog, target) -> applyArt(id, target))
                  .setNegativeButton("Desktop only", null)
                  .show();
            })
        .setNeutralButton("Save / unsave", (d, n) -> toggle("saved_art", "" + id))
        .setNegativeButton("Close", null)
        .show();
  }

  void applyArt(int id, int target) {
    toast("Rendering wallpaper…");
    worker.submit(
        () -> {
          Bitmap b = null;
          try {
            b = Art.bitmap(1440, 2560, id);
            WallpaperManager.getInstance(this)
                .setBitmap(
                    b,
                    null,
                    false,
                    target == 0
                        ? WallpaperManager.FLAG_SYSTEM
                        : target == 1
                            ? WallpaperManager.FLAG_LOCK
                            : WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            ui.post(() -> toast("Wallpaper applied"));
          } catch (Exception e) {
            ui.post(() -> toast("Could not apply wallpaper on this device."));
          } finally {
            if (b != null) b.recycle();
          }
        });
  }

  @Override
  protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request == 71 && result == RESULT_OK && data != null && data.getData() != null) {
      final Uri uri = data.getData();
      new AlertDialog.Builder(this)
          .setTitle("Apply imported photo")
          .setItems(
              new String[] {"Home screen", "Lock screen", "Both"},
              (d, n) ->
                  worker.submit(
                      () -> {
                        Bitmap b = null;
                        try {
                          ImageDecoder.Source source =
                              ImageDecoder.createSource(getContentResolver(), uri);
                          b =
                              ImageDecoder.decodeBitmap(
                                  source,
                                  (decoder, info, src) -> {
                                    int max =
                                        Math.max(
                                            info.getSize().getWidth(), info.getSize().getHeight());
                                    decoder.setTargetSampleSize(Math.max(1, (max + 2559) / 2560));
                                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                                  });
                          WallpaperManager.getInstance(this)
                              .setBitmap(
                                  b,
                                  null,
                                  false,
                                  n == 0
                                      ? WallpaperManager.FLAG_SYSTEM
                                      : n == 1
                                          ? WallpaperManager.FLAG_LOCK
                                          : WallpaperManager.FLAG_SYSTEM
                                              | WallpaperManager.FLAG_LOCK);
                          ui.post(
                              () ->
                                  toast(
                                      "Photo wallpaper applied. AURA desktop keeps its selected"
                                          + " gallery artwork."));
                        } catch (Exception e) {
                          ui.post(() -> toast("Cannot read this image or apply wallpaper."));
                        } finally {
                          if (b != null) b.recycle();
                        }
                      }))
          .setNegativeButton("Cancel", null)
          .show();
    }
  }

  @Override
  void focus() {
    heading("DEEP WORK", "Focus room", "A quiet place for your next important task.");
    countdown = label("", 64);
    countdown.setGravity(Gravity.CENTER);
    body.addView(countdown);
    updateFocus();
    tiles(
        body,
        new String[] {"25 minutes", "50 minutes"},
        new Runnable[] {() -> startFocus(25), () -> startFocus(50)});
    button(
        body,
        "End session",
        () -> {
          focusEnd = 0;
          prefs.edit().putLong("timer_end", 0).apply();
          render();
        });
    button(
        body,
        "Open Do Not Disturb controls",
        () -> go(new Intent("android.settings.ZEN_MODE_SETTINGS")));
    card("YOUR TASK", prefs.getString("intention", "Make room for exceptional things."));
    button(
        body,
        "Edit intention",
        () ->
            input(
                "One important task",
                prefs.getString("intention", ""),
                s -> {
                  prefs.edit().putString("intention", s).apply();
                  render();
                }));
    info(
        "Countdown survives app restart on this boot. No background alarm or app blocking. Reboot"
            + " clears the timer.");
  }

  void startFocus(int minutes) {
    focusEnd = SystemClock.elapsedRealtime() + minutes * 60000L;
    prefs
        .edit()
        .putLong("timer_end", focusEnd)
        .putInt(
            "timer_boot",
            Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT, -1))
        .apply();
    render();
  }

  @Override
  void updateFocus() {
    if (countdown == null) return;
    long sec = Math.max(0, (focusEnd - SystemClock.elapsedRealtime() + 999) / 1000);
    countdown.setText(
        focusEnd == 0 ? "Ready" : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60));
    if (focusEnd > 0 && sec == 0) {
      focusEnd = 0;
      prefs.edit().putLong("timer_end", 0).apply();
      toast("Focus session complete");
    }
  }

  void tools() {
    heading(
        "PERSONAL UTILITIES",
        "Your toolkit",
        "Small tools. No accounts. Everything stays on your phone.");
    tiles(
        body,
        new String[] {
          "◷  Focus room",
          "▤  Checklist",
          "＋  Calculator",
          "↔  Unit converter",
          "✎  Scratchpad",
          "▦  Month view"
        },
        new Runnable[] {
          () -> navigate("Focus"),
          () -> checklist(),
          () -> calculator(),
          () -> converter(),
          () -> scratchpad(),
          () -> month()
        });
    button(
        body,
        "Presentation mode: " + (prefs.getBoolean("presentation", false) ? "On" : "Off"),
        () -> {
          prefs.edit().putBoolean("presentation", !prefs.getBoolean("presentation", false)).apply();
          render();
        });
    info("Presentation mode hides your intention on the desktop. It is not a system privacy lock.");
    button(
        body, "Internet panel", () -> go(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)));
    button(
        body, "Alarm clock", () -> go(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)));
    button(body, "Device settings", () -> go(new Intent(Settings.ACTION_SETTINGS)));
    button(body, "Export / import desktop preferences", () -> settingsTransfer());
  }

  void scratchpad() {
    EditText e = new EditText(this);
    e.setTextColor(Color.WHITE);
    e.setMinLines(6);
    e.setGravity(Gravity.TOP);
    e.setText(prefs.getString("scratch", ""));
    new AlertDialog.Builder(this)
        .setTitle("Scratchpad / not encrypted")
        .setView(e)
        .setPositiveButton(
            "Save", (d, n) -> prefs.edit().putString("scratch", e.getText().toString()).apply())
        .setNegativeButton("Cancel", null)
        .show();
  }

  org.json.JSONArray tasks() {
    try {
      return new org.json.JSONArray(prefs.getString("tasks", "[]"));
    } catch (Exception e) {
      return new org.json.JSONArray();
    }
  }

  void checklist() {
    org.json.JSONArray a = tasks();
    String[] names = new String[a.length()];
    boolean[] done = new boolean[a.length()];
    for (int i = 0; i < a.length(); i++) {
      org.json.JSONObject o = a.optJSONObject(i);
      names[i] = o.optString("name");
      done[i] = o.optBoolean("done");
    }
    new AlertDialog.Builder(this)
        .setTitle("My checklist / local")
        .setMultiChoiceItems(
            names,
            done,
            (d, n, on) -> {
              try {
                a.getJSONObject(n).put("done", on);
                prefs.edit().putString("tasks", a.toString()).apply();
              } catch (Exception ignored) {
              }
            })
        .setPositiveButton(
            "Add task",
            (d, n) ->
                input(
                    "New task",
                    "",
                    s -> {
                      if (!s.isEmpty())
                        try {
                          a.put(new org.json.JSONObject().put("name", s).put("done", false));
                          prefs.edit().putString("tasks", a.toString()).apply();
                          checklist();
                        } catch (Exception ignored) {
                        }
                    }))
        .setNeutralButton(
            "Remove completed",
            (d, n) -> {
              org.json.JSONArray keep = new org.json.JSONArray();
              for (int i = 0; i < a.length(); i++)
                if (!a.optJSONObject(i).optBoolean("done")) keep.put(a.optJSONObject(i));
              prefs.edit().putString("tasks", keep.toString()).apply();
              checklist();
            })
        .setNegativeButton("Close", null)
        .show();
  }

  EditText number(LinearLayout box, String hint) {
    EditText e = new EditText(this);
    e.setTextColor(Color.WHITE);
    e.setHintTextColor(0xff94a8c2);
    e.setHint(hint);
    e.setInputType(
        android.text.InputType.TYPE_CLASS_NUMBER
            | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
    box.addView(e);
    return e;
  }

  void calculator() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(1);
    box.setPadding(dp(18), 0, dp(18), 0);
    EditText a = number(box, "First number"), b = number(box, "Second number");
    Spinner op = new Spinner(this);
    op.setAdapter(
        new ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            new String[] {"+", "−", "×", "÷", "% of"}));
    box.addView(op);
    TextView out = label("", 24);
    box.addView(out);
    button(
        box,
        "Calculate",
        () -> {
          try {
            double x = Double.parseDouble(a.getText().toString()),
                y = Double.parseDouble(b.getText().toString());
            int n = op.getSelectedItemPosition();
            if (n == 3 && y == 0) {
              out.setText("Cannot divide by zero");
              return;
            }
            double v =
                n == 0 ? x + y : n == 1 ? x - y : n == 2 ? x * y : n == 3 ? x / y : x * y / 100;
            out.setText(
                Double.isFinite(v)
                    ? String.format(Locale.getDefault(), "%.8g", v)
                    : "Result out of range");
          } catch (Exception e) {
            out.setText("Enter two valid numbers");
          }
        });
    new AlertDialog.Builder(this)
        .setTitle("Quick calculator")
        .setView(box)
        .setNegativeButton("Close", null)
        .show();
  }

  void converter() {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(1);
    box.setPadding(dp(18), 0, dp(18), 0);
    EditText in = number(box, "Value");
    Spinner mode = new Spinner(this);
    mode.setAdapter(
        new ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            new String[] {"km → miles", "miles → km", "°C → °F", "°F → °C", "kg → lb", "lb → kg"}));
    box.addView(mode);
    TextView out = label("", 24);
    box.addView(out);
    button(
        box,
        "Convert",
        () -> {
          try {
            double x = Double.parseDouble(in.getText().toString());
            int n = mode.getSelectedItemPosition();
            double v =
                n == 0
                    ? x * .621371192
                    : n == 1
                        ? x / .621371192
                        : n == 2
                            ? x * 9 / 5 + 32
                            : n == 3 ? (x - 32) * 5 / 9 : n == 4 ? x * 2.20462262 : x / 2.20462262;
            out.setText(
                Double.isFinite(v)
                    ? String.format(Locale.getDefault(), "%.6g", v)
                    : "Value out of range");
          } catch (Exception e) {
            out.setText("Enter a valid number");
          }
        });
    new AlertDialog.Builder(this)
        .setTitle("Unit converter")
        .setView(box)
        .setNegativeButton("Close", null)
        .show();
  }

  void month() {
    CalendarView c = new CalendarView(this);
    new AlertDialog.Builder(this)
        .setTitle("Calendar / view only")
        .setView(c)
        .setPositiveButton("Close", null)
        .show();
  }

  void settingsTransfer() {
    new AlertDialog.Builder(this)
        .setTitle("Desktop preferences")
        .setMessage(
            "Transfer palettes, artwork, owner name and layout as JSON. Notes, hidden apps and"
                + " other private data are excluded.")
        .setPositiveButton(
            "Export",
            (d, n) -> {
              try {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("format", 2)
                    .put("owner", prefs.getString("owner", "KELVIN"))
                    .put("theme", prefs.getInt("theme", 0))
                    .put("art", selectedArt())
                    .put("layout", prefs.getString("layout", "Atelier"));
                String data = o.toString(2);
                new AlertDialog.Builder(this)
                    .setTitle("Copy desktop JSON")
                    .setMessage(data)
                    .setPositiveButton(
                        "Copy",
                        (x, y) -> {
                          ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                              .setPrimaryClip(ClipData.newPlainText("AURA preferences", data));
                          toast("Desktop preferences copied");
                        })
                    .setNegativeButton("Close", null)
                    .show();
              } catch (Exception e) {
                toast("Export failed");
              }
            })
        .setNeutralButton(
            "Import",
            (d, n) ->
                input(
                    "Paste desktop JSON",
                    "",
                    s -> {
                      try {
                        org.json.JSONObject o = new org.json.JSONObject(s);
                        int theme = o.getInt("theme"), art = o.getInt("art");
                        String owner = o.getString("owner"), layout = o.getString("layout");
                        if (o.getInt("format") != 2
                            || theme < 0
                            || theme > 3
                            || art < 0
                            || art > 47
                            || owner.length() > 24
                            || !Arrays.asList(modes).contains(layout)) throw new Exception();
                        prefs
                            .edit()
                            .putString("owner", owner)
                            .putInt("theme", theme)
                            .putInt("art", art)
                            .putString("layout", layout)
                            .apply();
                        render();
                        toast("Desktop restored");
                      } catch (Exception e) {
                        toast("Invalid AURA desktop JSON. Nothing changed.");
                      }
                    }))
        .setNegativeButton("Cancel", null)
        .show();
  }

  @Override
  public void onBackPressed() {
    if (vaultOpen || !page.equals("Home")) navigate("Home");
    else if (!getSystemService(RoleManager.class).isRoleHeld(RoleManager.ROLE_HOME))
      super.onBackPressed();
  }
}
